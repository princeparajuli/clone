# Facebook Clone using HTML, CSS and JS from team @SIR

[]: # (c) 2020 SIR

[]: # License: MIT

[]: # Version: 1.0.0

[]: # Date: 2020-06-30

[]: # Title: Facebook Clone

[]: # Description: Facebook Clone using HTML, CSS and JS from team @SIR

# Facebook Clone
